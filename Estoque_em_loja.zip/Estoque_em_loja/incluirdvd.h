#ifndef INCLUIRDVD_H
#define INCLUIRDVD_H

#include <QDialog>

namespace Ui {
class incluirDVD;
}

class incluirDVD : public QDialog
{
    Q_OBJECT

public:
    explicit incluirDVD(QWidget *parent = nullptr);
    ~incluirDVD();

    void clear(); //Limpar QLineEdit

private slots:
    void on_buttonBox_accepted();

private:
    Ui::incluirDVD *ui;

signals:
    void signlIncluirDVD(QString nome, QString preco, QString duracao);
};

#endif // INCLUIRDVD_H
