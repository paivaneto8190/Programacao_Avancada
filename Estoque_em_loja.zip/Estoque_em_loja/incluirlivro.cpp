#include "incluirlivro.h"
#include "ui_incluirlivro.h"

incluirlivro::incluirlivro(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::incluirlivro)
{
    ui->setupUi(this);
}

incluirlivro::~incluirlivro()
{
    delete ui;
}

void incluirlivro::clear() { //Limpa os LineEdits da janela de inclusao de livros
    ui -> line_nome_livro -> setText(""); //QLineEdit 1
    ui -> line_preco_livro -> setText(""); //QLineEdit 2
    ui-> line_autor -> setText(""); //QLineEdit 3
}

void incluirlivro::on_buttonBox_accepted()
{
   QString nome,preco, autor;

   nome = ui -> line_nome_livro -> text();
   preco = ui -> line_preco_livro -> text();
   autor = ui -> line_autor -> text();

   emit signlIncluirLivro(nome, preco, autor);

   clear(); //limpar o 3 QLineEdit
}

