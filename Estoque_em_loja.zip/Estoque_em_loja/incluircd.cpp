#include "incluircd.h"
#include "ui_incluircd.h"

incluirCD::incluirCD(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::incluirCD)
{
    ui->setupUi(this);
}

incluirCD::~incluirCD()
{
    delete ui;
}


void incluirCD::clear() { //Limpa os LineEdits da janela de inclusao de livros
    ui -> line_nome_cd -> setText(""); //QLineEdit 1
    ui -> line_preco_cd -> setText(""); //QLineEdit 2
    ui-> line_numfaixas -> setText(""); //QLineEdit 3
}


void incluirCD::on_buttonBox_accepted()
{
    QString nome, preco, numFaixas;

    nome = ui -> line_nome_cd -> text();
    preco = ui -> line_preco_cd -> text();
    numFaixas = ui -> line_numfaixas -> text();

    emit signlIncluirCD(nome, preco, numFaixas);

    clear(); //Limpa o 3 QLineEdits de CDlimpa os 3 QLineEdit
}

