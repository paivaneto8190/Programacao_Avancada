#ifndef INCLUIRCD_H
#define INCLUIRCD_H

#include <QDialog>

namespace Ui {
class incluirCD;
}

class incluirCD : public QDialog
{
    Q_OBJECT

public:
    explicit incluirCD(QWidget *parent = nullptr);
    ~incluirCD();

    void clear(); //Limpar QLineEdit

private slots:
    void on_buttonBox_accepted();

private:
    Ui::incluirCD *ui;

signals:
    void signlIncluirCD(QString nome, QString preco, QString numFaixas);
};

#endif // INCLUIRCD_H
