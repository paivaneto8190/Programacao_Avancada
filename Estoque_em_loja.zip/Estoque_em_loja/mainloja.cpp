#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QCoreApplication>
#include <QProcess>
#include <QHeaderView>

#include "mainloja.h"
#include "ui_mainloja.h"

#include "loja.h"
#include "incluirlivro.h"
#include "incluircd.h"
#include "incluirdvd.h"

MainLoja::MainLoja(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainLoja)
    , X() ///Armazena informacoes de estoque
    , inclLivro(nullptr)
    , inclCD(nullptr)
    , inclDVD(nullptr)
    , total_itens(nullptr)
{
    ui->setupUi(this);

    inclLivro = new incluirlivro (this);
    inclCD = new incluirCD (this);
    inclDVD = new incluirDVD (this);
    total_itens = new QLabel (this);

    ///Inserir QWidgets na barra de status
    statusBar() -> insertWidget(0, new QLabel("Total de itens: "));
    statusBar() -> insertWidget(1, total_itens);

    ///Conectando sinais e slots das classes IncluirLivro, IncluirCD e IncluirDVD
    //IncluirLivro
    connect (inclLivro, &incluirlivro::signlIncluirLivro,
             this, &MainLoja::slotIncluirLivro);

    //IncluirCD
    connect (inclCD, &incluirCD::signlIncluirCD,
             this, &MainLoja::slotIncluirCD);

    //IncluirDVD
    connect (inclDVD, &incluirDVD::signlIncluirDVD,
             this, &MainLoja::slotIncluirDVD);

    ///Alterar aspectos da interface
    //Cores das tabelas
    ui -> tabela_livros -> setStyleSheet("lightgray");
    ui -> tabela_cds -> setStyleSheet("lightgray");
    ui -> tabela_dvds -> setStyleSheet("lightgray");

    //Cores dos cabecalhos das tabelas
    ui -> tabela_livros -> setStyleSheet("QHeaderView::section{background-color:lightgray}");
    ui -> tabela_cds -> setStyleSheet("QHeaderView::section{background-color:lightgray}");
    ui -> tabela_dvds -> setStyleSheet("QHeaderView::section{background-color:lightgray}");

    ///Ajustar tamanho das tabelas
    //Livros
    ui -> tabela_livros-> horizontalHeader() -> setSectionResizeMode(0,QHeaderView::Stretch);
    ui -> tabela_livros-> horizontalHeader() -> setSectionResizeMode(1,QHeaderView::ResizeToContents);
    ui -> tabela_livros-> horizontalHeader() -> setSectionResizeMode(2,QHeaderView::ResizeToContents);

    //CDs
    ui -> tabela_cds-> horizontalHeader() -> setSectionResizeMode(0,QHeaderView::Stretch);
    ui -> tabela_cds-> horizontalHeader() -> setSectionResizeMode(1,QHeaderView::ResizeToContents);
    ui -> tabela_cds-> horizontalHeader() -> setSectionResizeMode(2,QHeaderView::ResizeToContents);

    //DVDs
    ui -> tabela_dvds-> horizontalHeader() -> setSectionResizeMode(0,QHeaderView::Stretch);
    ui -> tabela_dvds-> horizontalHeader() -> setSectionResizeMode(1,QHeaderView::ResizeToContents);
    ui -> tabela_dvds-> horizontalHeader() -> setSectionResizeMode(2,QHeaderView::ResizeToContents);

    ///Fixa texto das tabelas
    ui -> tabela_livros -> setHorizontalHeaderLabels(QStringList() << "NOME" << "PRECO" << "AUTOR");
    ui -> tabela_cds -> setHorizontalHeaderLabels(QStringList() << "NOME" << "PRECO" << "N FAIXAS");
    ui -> tabela_dvds -> setHorizontalHeaderLabels(QStringList() << "NOME" << "PRECO" << "DURACAO");

    ///Exibindo itens
    exibe_livros (X); //Livros
    exibe_CDS (X); //CDs
    exibe_DVDS (X); //DVDs
}

MainLoja::~MainLoja()
{
    delete ui;
}

///===========================================================================
///Exibir total de itens na barra de status
void MainLoja::exibe_total_itens () {
    total_itens -> setNum(int(X.getNumLivro() + X.getNumCD() + X.getNumDVD()));
}
///===========================================================================


///===========================================================================
///Funcao para exibir os livros
void MainLoja::exibe_livros (Loja& X) {
    unsigned i, j;

    ui->tabela_livros->clearContents();
    ui->tabela_livros->setRowCount(X.getNumLivro());

    for (i = 0; i < X.getNumLivro(); i++) { //Varrer as linhas
        for (j = 0; j < 3; j++) { //Varrer colunas
            if (j == 0) {
                QLabel *aux_exibir = new QLabel(QString(X.getLivro(j).getNome().c_str()));
                ui->tabela_livros->setCellWidget(i, j, aux_exibir);
           }
           else if (j == 1) {
                QLabel *aux_exibir = new QLabel(QString::number(X.getLivro(j).getPreco(),'f',2));
                ui->tabela_livros->setCellWidget(i, j, aux_exibir);
           }
           else {
                QLabel *aux_exibir = new QLabel(X.getLivro(j).getAutor().c_str());
                ui->tabela_livros->setCellWidget(i, j, aux_exibir);
           }
        }
    }
}


///Funcao para exibir os cds
void MainLoja::exibe_CDS (Loja& X) {
    unsigned i, j;

    ui->tabela_cds->clearContents();
    ui->tabela_cds->setRowCount(X.getNumCD());

    for (i = 0; i < X.getNumCD(); i++) { //Varrer as linhas
        for (j = 0; j < 3; j++) { //Varrer colunas
            if (j == 0) {
                QLabel *aux_exibir = new QLabel(QString(X.getCD(j).getNome().c_str()));
                ui->tabela_cds->setCellWidget(i, j, aux_exibir);
           }
           else if (j == 1) {
                QLabel *aux_exibir = new QLabel(QString::number(X.getCD(j).getPreco(),'f',2));
                ui->tabela_cds->setCellWidget(i, j, aux_exibir);
           }
           else {
                QLabel *aux_exibir = new QLabel(QString::number(X.getCD(j).getNumFaixas()));
                ui->tabela_cds->setCellWidget(i, j, aux_exibir);
           }
        }
    }
}


///Funcao para exibir os dvds
void MainLoja::exibe_DVDS (Loja& X) {
    unsigned i, j;

    ui->tabela_dvds->clearContents();
    ui->tabela_dvds->setRowCount(X.getNumDVD());

    for (i = 0; i < X.getNumDVD(); i++) { //Varrer as linhas
        for (j = 0; j < 3; j++) { //Varrer colunas
            if (j == 0) {
                QLabel *aux_exibir = new QLabel(QString(X.getDVD(j).getNome().c_str()));
                ui->tabela_dvds->setCellWidget(i, j, aux_exibir);
           }
           else if (j == 1) {
                QLabel *aux_exibir = new QLabel(QString::number(X.getDVD(j).getPreco(),'f',2));
                ui->tabela_dvds->setCellWidget(i, j, aux_exibir);
           }
           else {
                QLabel *aux_exibir = new QLabel(QString::number(X.getDVD(j).getDuracao()));
                ui->tabela_dvds->setCellWidget(i, j, aux_exibir);
           }
        }
    }
}
///===========================================================================


///===========================================================================
void MainLoja::on_actionLer_triggered() ///Ler um arquivo
{
    QString fileName = QFileDialog::
          getOpenFileName(this,
                          "Ler estoque",
                          QString(),
                          "Text Files (*.txt);;C++ Files (*.cpp *.h)");

      if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) {
          // mensagem de erro
          QMessageBox::critical(this, tr("Erro"), tr("Erro ao abrir o arquivo"));
          return;
        }
        QTextStream in(&file);
        X.ler(fileName.toStdString());
        file.close();
      }

}

void MainLoja::on_actionSalvar_triggered() ///Salvar um arquivo
{
    QString fileName = QFileDialog::
          getSaveFileName(this,
                          "Salvar estoque",
                          QString(),
                          "Text Files (*.txt);;C++ Files (*.cpp *.h)");

      if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly)) {
            // mensagem de erro
            QMessageBox::critical(this, tr("Erro"), tr("Erro ao abrir o arquivo"));
            return;
        }
        QTextStream stream(&file);
        stream << X.salvar(fileName.toStdString());
        stream.flush();
        file.close();
      }
}

void MainLoja::on_actionSair_triggered() ///Sair do programa
{
    QCoreApplication::quit();
}


///===========================================================================
void MainLoja::slotIncluirLivro(QString nome, QString preco, QString autor)
{
    Livro obj_livro(nome.toStdString(),round(preco.toFloat()*100.0),autor.toStdString());
    QString::number(obj_livro.getPreco(),'f', 2); //VERIFICAR SE PRECISA123

    //Para verificar se podemos incluir o livro no programa, fazemos
    if ((obj_livro.getNome() != " ") && (obj_livro.getPreco() != 0.0) && (obj_livro.getAutor() != " ")) {
        X.incluirLivro(obj_livro);
        exibe_livros(X);
    }
    else {
        QMessageBox::critical(this, "Livro invalido", QString("Não foi possivel incluir o Livro:\n")+ //Se não colocar QString dá erro ao compilar
                              "Nome= "+nome+"\nPreço="+preco+"\nAutor= "+autor); //Caso ocorra algum erro para adicionar o Livo
    }
}

void MainLoja::slotIncluirCD(QString nome, QString preco, QString numfaixas)
{
    CD obj_cd(nome.toStdString(),round(preco.toFloat()*100.0),numfaixas.toFloat());

    //Para verificar se podemos incluir o CD no programa, fazemos
    if ((obj_cd.getNome() != " ") && (obj_cd.getPreco() != 0.0) && (obj_cd.getNumFaixas() != 0)) {
        X.incluirCD(obj_cd);
        exibe_CDS(X);
    }
    else {
        QMessageBox::critical(this, "CD invalido", QString("Não foi possivel incluir o CD:\n")+ //Se não colocar QString dá erro ao compilar
                              "Nome= "+nome+"\nPreço="+preco+"\nNum faixas= "+numfaixas); //Caso ocorra algum erro para adicionar o CD
    }
}

void MainLoja::slotIncluirDVD(QString nome, QString preco, QString duracao)
{
    DVD obj_dvd(nome.toStdString(),round(preco.toFloat()*100.0),duracao.toFloat());

    //Para verificar se podemos incluir o DVD no programa, fazemos
    if ((obj_dvd.getNome() != " ") && (obj_dvd.getPreco() != 0.0) && (obj_dvd.getDuracao() != 0.0)) {
        X.incluirDVD(obj_dvd);
        exibe_DVDS(X);
    }
    else {
        QMessageBox::critical(this, "DVD invalido", QString("Não foi possivel incluir o DVD:\n")+ //Se não colocar QString dá erro ao compilar
                              "Nome= "+nome+"\nPreço="+preco+"\nDuração= "+duracao); //Caso ocorra algum erro para adicionar o DVD
    }
}
///===========================================================================


///===========================================================================
void MainLoja::on_actionIncluir_livro_triggered()
{
    inclLivro->show();
}


void MainLoja::on_actionIncluir_CD_triggered()
{
    inclCD->show();
}


void MainLoja::on_actionIncluir_DVD_triggered()
{

    inclDVD->show();
}


///===========================================================================
/// Em caso de um duplo clique, os objetos serao excluidos
void MainLoja::on_tabela_livros_cellDoubleClicked(int row, int column)
{
   if (unsigned(row) < X.getNumLivro()) { //Convertemos row para poder comparar
       X.excluirLivro(row);
       exibe_livros(X);
   }
   else {
       QMessageBox::critical(this, tr ("Erro"), tr ("Erro ao excluir o livro selecionado")); //Caso ocorra algum erro para excluir o livro
   }
}


void MainLoja::on_tabela_cds_cellDoubleClicked(int row, int column)
{
    if (unsigned(row) < X.getNumCD()) { //Convertemos row para poder comparar
        X.excluirCD(row);
        exibe_CDS(X);
    }
    else {
        QMessageBox::critical(this, tr ("Erro"), tr ("Erro ao excluir o CD selecionado")); //Caso ocorra algum erro para excluir o CD
    }
}


void MainLoja::on_tabela_dvds_cellDoubleClicked(int row, int column)
{
    if (unsigned(row) < X.getNumDVD()) { //Convertemos row para poder comparar
        X.excluirDVD(row);
        exibe_DVDS(X);
    }
    else {
        QMessageBox::critical(this, tr ("Erro"), tr ("Erro ao excluir o DVD selecionado")); //Caso ocorra algum erro para excluir o DVD
    }
}
