#ifndef INCLUIRLIVRO_H
#define INCLUIRLIVRO_H

#include <QDialog>

namespace Ui {
class incluirlivro;
}

class incluirlivro : public QDialog
{
    Q_OBJECT

public:
    explicit incluirlivro(QWidget *parent = nullptr);
    ~incluirlivro();

    void clear(); //Limpar QLineEdit

private slots:
    void on_buttonBox_accepted();

private:
    Ui::incluirlivro *ui;

signals:
    void signlIncluirLivro(QString nome, QString preco, QString autor);
};

#endif // INCLUIRLIVRO_H
