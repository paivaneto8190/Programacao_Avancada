#include "mainloja.h"
#include "ui_mainloja.h"

#include "loja.h"
#include "incluirlivro.h"
#include "incluircd.h"
#include "incluirdvd.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainLoja w;
    w.show();
    return a.exec();
}
