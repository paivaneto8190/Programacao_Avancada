#include "incluirdvd.h"
#include "ui_incluirdvd.h"

incluirDVD::incluirDVD(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::incluirDVD)
{
    ui->setupUi(this);
}

incluirDVD::~incluirDVD()
{
    delete ui;
}

void incluirDVD::clear() { //Limpa os LineEdits da janela de inclusao de livros
    ui -> line_nome_dvd -> setText(""); //QLineEdit 1
    ui -> line_preco_dvd -> setText(""); //QLineEdit 2
    ui-> line_duracao -> setText(""); //QLineEdit 3
}

void incluirDVD::on_buttonBox_accepted()
{
    QString nome, preco, duracao;

    nome = ui -> line_nome_dvd -> text();
    preco = ui -> line_preco_dvd -> text();
    duracao = ui -> line_duracao -> text();

    emit signlIncluirDVD(nome, preco, duracao);

    clear(); //Limpar os QLineEdit

}

